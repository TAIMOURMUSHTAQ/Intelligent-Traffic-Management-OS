#include "traffic.h"

sem_t lane_sem;
sem_t intersection_sem;

void init_sync(void) {
    /* Lane semaphore: up to 3 vehicles may be in lanes simultaneously */
    if (sem_init(&lane_sem, 0, 3) != 0) {
        perror("sem_init lane_sem");
        exit(EXIT_FAILURE);
    }
    /* Intersection semaphore: only 1 vehicle in intersection at a time */
    if (sem_init(&intersection_sem, 0, 1) != 0) {
        perror("sem_init intersection_sem");
        exit(EXIT_FAILURE);
    }
    printf(GREEN "  [SYNC] Semaphores initialized: Lane(3), Intersection(1)\n" RESET);
}

void destroy_sync(void) {
    sem_destroy(&lane_sem);
    sem_destroy(&intersection_sem);
}

void enter_lane(int vid) {
    printf(YELLOW "  [SYNC] Vehicle %d waiting for lane semaphore...\n" RESET, vid);
    sem_wait(&lane_sem);
    printf(GREEN  "  [SYNC] Vehicle %d acquired lane semaphore.\n" RESET, vid);
}

void leave_lane(int vid) {
    sem_post(&lane_sem);
    printf(CYAN   "  [SYNC] Vehicle %d released lane semaphore.\n" RESET, vid);
}

void enter_intersection(int vid) {
    pthread_mutex_lock(&shared->table_mutex);
    printf(YELLOW "  [MUTEX] Vehicle %d waiting for intersection mutex...\n" RESET, vid);
    pthread_mutex_unlock(&shared->table_mutex);

    sem_wait(&intersection_sem);

    pthread_mutex_lock(&shared->table_mutex);
    printf(GREEN  "  [MUTEX] Vehicle %d locked intersection (critical section).\n" RESET, vid);
    pthread_mutex_unlock(&shared->table_mutex);
}

void leave_intersection(int vid) {
    sem_post(&intersection_sem);
    pthread_mutex_lock(&shared->table_mutex);
    printf(CYAN   "  [MUTEX] Vehicle %d unlocked intersection.\n" RESET, vid);
    pthread_mutex_unlock(&shared->table_mutex);
}

/* ── Thread-based sync demo ───────────────────────────────────── */
typedef struct { int id; } ThreadArg;

static void *vehicle_thread(void *arg) {
    ThreadArg *ta = (ThreadArg *)arg;
    int id = ta->id;

    enter_lane(id);
    demo_pause(200);
    enter_intersection(id);
    printf(MAGENTA "  [THREAD] Vehicle %d passing through intersection.\n" RESET, id);
    demo_pause(300);
    leave_intersection(id);
    leave_lane(id);

    free(ta);
    return NULL;
}

void demo_sync(int vehicle_count) {
    print_section("Synchronization Demo: Mutex + Semaphores");
    printf("  %d vehicle threads compete for lane (cap=3) and intersection (cap=1).\n\n",
           vehicle_count);

    pthread_t threads[MAX_VEHICLES];
    int count = (vehicle_count > MAX_VEHICLES) ? MAX_VEHICLES : vehicle_count;

    for (int i = 0; i < count; i++) {
        ThreadArg *ta = malloc(sizeof(ThreadArg));
        ta->id = i + 1;
        pthread_create(&threads[i], NULL, vehicle_thread, ta);
        demo_pause(50);
    }
    for (int i = 0; i < count; i++)
        pthread_join(threads[i], NULL);

    printf(GREEN "\n  [SYNC] All vehicles passed. No race conditions detected.\n" RESET);
}
