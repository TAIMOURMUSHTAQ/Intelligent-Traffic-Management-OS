#include "traffic.h"

static volatile sig_atomic_t emergency_active = 0;
static volatile sig_atomic_t traffic_paused   = 0;

/* ── Handlers ─────────────────────────────────────────────────── */
static void handle_sigusr1(int sig) {
    (void)sig;
    emergency_active = 1;
    const char *msg = "\n  [SIGNAL] SIGUSR1: Emergency vehicle! All traffic stopped.\n";
    ssize_t r = write(STDOUT_FILENO, msg, strlen(msg)); (void)r;
}

static void handle_sigusr2(int sig) {
    (void)sig;
    emergency_active = 0;
    const char *msg = "\n  [SIGNAL] SIGUSR2: Emergency cleared. Traffic resuming.\n";
    ssize_t r = write(STDOUT_FILENO, msg, strlen(msg)); (void)r;
}

static void handle_sigstop_sim(int sig) {
    (void)sig;
    traffic_paused = 1;
    const char *msg = "\n  [SIGNAL] SIGTSTP: Traffic flow paused.\n";
    ssize_t r = write(STDOUT_FILENO, msg, strlen(msg)); (void)r;
}

static void handle_sigcont(int sig) {
    (void)sig;
    traffic_paused = 0;
    const char *msg = "\n  [SIGNAL] SIGCONT: Traffic flow resumed.\n";
    ssize_t r = write(STDOUT_FILENO, msg, strlen(msg)); (void)r;
}

static void handle_sigint(int sig) {
    (void)sig;
    const char *msg = "\n  [SIGNAL] SIGINT received. Shutting down traffic system...\n";
    ssize_t r = write(STDOUT_FILENO, msg, strlen(msg)); (void)r;
    _exit(0);
}

static void handle_sigchld(int sig) {
    (void)sig;
    /* Reap zombies non-blocking */
    while (waitpid(-1, NULL, WNOHANG) > 0) {}
}

void setup_signal_handlers(void) {
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sigemptyset(&sa.sa_mask);

    sa.sa_handler = handle_sigusr1;  sigaction(SIGUSR1,  &sa, NULL);
    sa.sa_handler = handle_sigusr2;  sigaction(SIGUSR2,  &sa, NULL);
    sa.sa_handler = handle_sigcont;  sigaction(SIGCONT,  &sa, NULL);
    sa.sa_handler = handle_sigint;   sigaction(SIGINT,   &sa, NULL);
    sa.sa_handler = handle_sigchld;  sigaction(SIGCHLD,  &sa, NULL);
    sa.sa_handler = handle_sigstop_sim; sigaction(SIGTSTP, &sa, NULL);

    printf(GREEN "  [SIGNAL] Handlers installed: SIGUSR1, SIGUSR2, SIGCONT, SIGINT, SIGCHLD, SIGTSTP\n" RESET);
}

void send_emergency(pid_t pid) {
    printf(RED "\n  [SIGNAL] Sending SIGUSR1 (emergency) to PID %d\n" RESET, (int)pid);
    kill(pid, SIGUSR1);
    sleep(1);
    printf(GREEN "  [SIGNAL] Sending SIGUSR2 (clear) to PID %d\n" RESET, (int)pid);
    kill(pid, SIGUSR2);
}

/* ── Full Signal Demo ─────────────────────────────────────────── */
void demo_signals(void) {
    print_section("Signal Handling Demo");
    printf("  Signals used: SIGUSR1 (emergency), SIGUSR2 (clear),\n");
    printf("                SIGSTOP/SIGCONT (pause/resume), SIGINT (shutdown)\n\n");

    pid_t child = fork();
    if (child < 0) { perror("fork"); return; }

    if (child == 0) {
        /* Child: install handlers and loop */
        setup_signal_handlers();
        printf(CYAN "  [VEHICLE PID=%d] On road, waiting for signals...\n" RESET,
               getpid());
        for (int i = 0; i < 5; i++) {
            sleep(1);
            if (emergency_active)
                printf(RED "  [VEHICLE PID=%d] Pulled over for emergency.\n" RESET,
                       getpid());
            else if (traffic_paused)
                printf(YELLOW "  [VEHICLE PID=%d] Traffic paused.\n" RESET, getpid());
            else
                printf(GREEN "  [VEHICLE PID=%d] Moving normally.\n" RESET, getpid());
        }
        exit(0);
    }

    /* Parent: send sequence of signals */
    sleep(1);
    printf(YELLOW "\n  [CONTROLLER] Sending SIGUSR1 (emergency) to vehicle PID %d\n" RESET,
           (int)child);
    kill(child, SIGUSR1);
    sleep(2);

    printf(GREEN "  [CONTROLLER] Sending SIGUSR2 (clear) to vehicle PID %d\n" RESET,
           (int)child);
    kill(child, SIGUSR2);
    sleep(1);

    printf(YELLOW "  [CONTROLLER] Sending SIGTSTP (pause) to vehicle PID %d\n" RESET,
           (int)child);
    kill(child, SIGTSTP);
    sleep(1);

    printf(GREEN "  [CONTROLLER] Sending SIGCONT (resume) to vehicle PID %d\n" RESET,
           (int)child);
    kill(child, SIGCONT);

    waitpid(child, NULL, 0);
    printf(GREEN "\n  [SIGNALS] Demo complete.\n" RESET);
}
