#include "traffic.h"

/* forward declarations for functions defined in other files */
void demo_sync(int vehicle_count);
void demo_banker(void);
void demo_pipe_ipc(void);
void demo_msgq_ipc(void);
void demo_shm_ipc(void);
void demo_signals(void);
void shm_init(void);

/* ── cleanup on exit ──────────────────────────────────────────── */
static void cleanup(void) {
    destroy_sync();
    ipc_cleanup();
}

/* ── menu ─────────────────────────────────────────────────────── */
static void print_menu(void) {
    printf("\n");
    printf(CYAN "  ╔══════════════════════════════════════════╗\n" RESET);
    printf(CYAN "  ║        Traffic System Main Menu          ║\n" RESET);
    printf(CYAN "  ╠══════════════════════════════════════════╣\n" RESET);
    printf(CYAN "  ║  " RESET "1.  FCFS Scheduling                    " CYAN "║\n" RESET);
    printf(CYAN "  ║  " RESET "2.  SJF Scheduling                     " CYAN "║\n" RESET);
    printf(CYAN "  ║  " RESET "3.  Round Robin Scheduling             " CYAN "║\n" RESET);
    printf(CYAN "  ║  " RESET "4.  Multilevel Queue Scheduling (MQS)  " CYAN "║\n" RESET);
    printf(CYAN "  ║  " RESET "5.  Mutex + Semaphore Demo             " CYAN "║\n" RESET);
    printf(CYAN "  ║  " RESET "6.  Banker's Algorithm Demo            " CYAN "║\n" RESET);
    printf(CYAN "  ║  " RESET "7.  Deadlock Simulation + Recovery     " CYAN "║\n" RESET);
    printf(CYAN "  ║  " RESET "8.  Pipe IPC Demo                      " CYAN "║\n" RESET);
    printf(CYAN "  ║  " RESET "9.  Message Queue IPC Demo             " CYAN "║\n" RESET);
    printf(CYAN "  ║  " RESET "10. Shared Memory IPC Demo             " CYAN "║\n" RESET);
    printf(CYAN "  ║  " RESET "11. Signal Handling Demo               " CYAN "║\n" RESET);
    printf(CYAN "  ║  " RESET "12. Full Auto-Demo (all modules)       " CYAN "║\n" RESET);
    printf(CYAN "  ║  " RESET "13. Print Vehicle Table                " CYAN "║\n" RESET);
    printf(CYAN "  ║  " RESET "0.  Exit                               " CYAN "║\n" RESET);
    printf(CYAN "  ╚══════════════════════════════════════════╝\n" RESET);
    printf(BOLD "  Choice: " RESET);
}

/* ── auto demo ────────────────────────────────────────────────── */
static void full_auto_demo(void) {
    print_section("Full Automated Demo – All Modules");
    printf("  Running every module in sequence...\n");
    demo_pause(500);

    printf(BOLD "\n  [1/11] Process Creation & Vehicle Table\n" RESET);
    print_vehicle_table();
    demo_pause(600);

    printf(BOLD "\n  [2/11] FCFS Scheduling\n" RESET);
    run_fcfs();
    demo_pause(600);

    printf(BOLD "\n  [3/11] SJF Scheduling\n" RESET);
    run_sjf();
    demo_pause(600);

    printf(BOLD "\n  [4/11] Round Robin\n" RESET);
    run_rr();
    demo_pause(600);

    printf(BOLD "\n  [5/11] Multilevel Queue Scheduling\n" RESET);
    run_mqs();
    demo_pause(600);

    printf(BOLD "\n  [6/11] Mutex + Semaphore Sync\n" RESET);
    demo_sync(5);
    demo_pause(600);

    printf(BOLD "\n  [7/11] Banker's Algorithm\n" RESET);
    demo_banker();
    demo_pause(600);

    printf(BOLD "\n  [8/11] Pipe IPC\n" RESET);
    demo_pipe_ipc();
    demo_pause(400);

    printf(BOLD "\n  [9/11] Message Queue IPC\n" RESET);
    demo_msgq_ipc();
    demo_pause(400);

    printf(BOLD "\n  [10/11] Shared Memory IPC\n" RESET);
    demo_shm_ipc();
    demo_pause(400);

    printf(BOLD "\n  [11/11] Signal Handling\n" RESET);
    demo_signals();
    demo_pause(400);

    printf(BOLD "\n  [BONUS] Deadlock Simulation + Recovery\n" RESET);
    simulate_deadlock();
    detect_and_recover();

    printf(GREEN "\n  Full demo complete. All OS concepts demonstrated successfully.\n" RESET);
}

/* ══════════════════════════════════════════════════════════════ */
int main(void) {
    srand((unsigned)time(NULL));

    /* IPC and shared memory */
    ipc_init();
    atexit(cleanup);

    /* Signals */
    setup_signal_handlers();

    /* Sync primitives */
    init_sync();

    /* Spawn vehicle processes / populate table */
    print_section("Initialising Traffic System");
    printf("  Generating vehicles via fork()...\n");

    int num_vehicles = 8;
    generate_vehicles(num_vehicles);

    printf(GREEN "  [FORK] %d vehicle processes registered.\n" RESET, num_vehicles);
    printf(CYAN  "  Resources available: Lanes=5, Intersections=3, Parking=4\n" RESET);

    /* Banner */
    print_header();

    int choice;
    do {
        print_menu();
        if (scanf("%d", &choice) != 1) { choice = 0; break; }

        switch (choice) {
            case 1:  run_fcfs();                    break;
            case 2:  run_sjf();                     break;
            case 3:  run_rr();                      break;
            case 4:  run_mqs();                     break;
            case 5:  demo_sync(num_vehicles);       break;
            case 6:  demo_banker();                 break;
            case 7:
                simulate_deadlock();
                detect_and_recover();
                break;
            case 8:  demo_pipe_ipc();               break;
            case 9:  demo_msgq_ipc();               break;
            case 10: demo_shm_ipc();                break;
            case 11: demo_signals();                break;
            case 12: full_auto_demo();              break;
            case 13: print_vehicle_table();         break;
            case 0:
                printf(GREEN "\n  Traffic system shutting down. Goodbye!\n\n" RESET);
                break;
            default:
                printf(RED "  Invalid choice. Try again.\n" RESET);
        }
    } while (choice != 0);

    return 0;
}
