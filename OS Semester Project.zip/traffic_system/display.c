#include "traffic.h"

pthread_mutex_t print_mutex = PTHREAD_MUTEX_INITIALIZER;

void print_header(void) {
    printf("\n");
    printf(CYAN "╔══════════════════════════════════════════════════════════════╗\n" RESET);
    printf(CYAN "║" BOLD "   Intelligent Traffic Management & Deadlock Prevention System  " CYAN "║\n" RESET);
    printf(CYAN "║" RESET "            Operating Systems Semester Project                  " CYAN "║\n" RESET);
    printf(CYAN "╚══════════════════════════════════════════════════════════════╝\n" RESET);
    printf("\n");
}

void print_section(const char *title) {
    printf("\n");
    printf(YELLOW "┌──────────────────────────────────────────────────────────────┐\n" RESET);
    printf(YELLOW "│  %-62s│\n" RESET, title);
    printf(YELLOW "└──────────────────────────────────────────────────────────────┘\n" RESET);
}

void print_separator(void) {
    printf(WHITE "────────────────────────────────────────────────────────────────\n" RESET);
}

void demo_pause(int ms) {
    struct timespec ts;
    ts.tv_sec  = ms / 1000;
    ts.tv_nsec = (ms % 1000) * 1000000L;
    nanosleep(&ts, NULL);
}
