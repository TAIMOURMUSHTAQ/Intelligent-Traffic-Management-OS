#include "traffic.h"

/*
 * Banker's Algorithm for Traffic Resource Allocation
 * Resources: [0] Lanes  [1] Intersections  [2] Parking Spots
 */

static int available[NUM_RESOURCES];
static int max_need[MAX_VEHICLES][NUM_RESOURCES];
static int allocation[MAX_VEHICLES][NUM_RESOURCES];
static int need[MAX_VEHICLES][NUM_RESOURCES];
static int n_vehicles = 0;

/* total units of each resource */
static const int TOTAL[NUM_RESOURCES] = {5, 3, 4};

int banker_init(void) {
    n_vehicles = shared->vehicle_count;

    for (int r = 0; r < NUM_RESOURCES; r++)
        available[r] = TOTAL[r];

    for (int i = 0; i < n_vehicles; i++) {
        for (int r = 0; r < NUM_RESOURCES; r++) {
            max_need[i][r]   = shared->vehicles[i].max_need[r];
            allocation[i][r] = 0;
            need[i][r]       = max_need[i][r];
        }
    }

    /* Copy back totals to shared memory */
    pthread_mutex_lock(&shared->table_mutex);
    for (int r = 0; r < NUM_RESOURCES; r++) {
        shared->available[r] = available[r];
        shared->total[r]     = TOTAL[r];
    }
    pthread_mutex_unlock(&shared->table_mutex);

    printf(GREEN "  [BANKER] Initialized. Resources: Lanes=%d, Intersections=%d, Parking=%d\n" RESET,
           TOTAL[0], TOTAL[1], TOTAL[2]);
    return 0;
}

/* ── Safety Algorithm ─────────────────────────────────────────── */
int safety_algorithm(void) {
    int work[NUM_RESOURCES];
    int finish[MAX_VEHICLES];
    int safe_seq[MAX_VEHICLES];
    int count = 0;

    for (int r = 0; r < NUM_RESOURCES; r++) work[r] = available[r];
    for (int i = 0; i < n_vehicles; i++) finish[i] = 0;

    while (count < n_vehicles) {
        int found = 0;
        for (int i = 0; i < n_vehicles; i++) {
            if (finish[i]) continue;
            int can = 1;
            for (int r = 0; r < NUM_RESOURCES; r++) {
                if (need[i][r] > work[r]) { can = 0; break; }
            }
            if (can) {
                for (int r = 0; r < NUM_RESOURCES; r++)
                    work[r] += allocation[i][r];
                finish[i]       = 1;
                safe_seq[count++] = i;
                found = 1;
            }
        }
        if (!found) break;
    }

    if (count == n_vehicles) {
        printf(GREEN "  [BANKER] System is in a SAFE state.\n"
                     "           Safe sequence: " RESET);
        for (int i = 0; i < n_vehicles; i++) {
            printf(CYAN "V%d" RESET, shared->vehicles[safe_seq[i]].id);
            if (i < n_vehicles - 1) printf(" → ");
        }
        printf("\n");
        return 1;   /* safe */
    }

    printf(RED "  [BANKER] System is in an UNSAFE state!\n" RESET);
    return 0;       /* unsafe */
}

/* ── Resource Request ─────────────────────────────────────────── */
int banker_request(int vehicle_id, int request[NUM_RESOURCES]) {
    int i = vehicle_id - 1;
    if (i < 0 || i >= n_vehicles) return -1;

    printf(YELLOW "  [BANKER] Vehicle %d requests [", vehicle_id);
    for (int r = 0; r < NUM_RESOURCES; r++)
        printf("%d%s", request[r], r < NUM_RESOURCES - 1 ? ", " : "");
    printf("]\n" RESET);

    /* Step 1: request ≤ need? */
    for (int r = 0; r < NUM_RESOURCES; r++) {
        if (request[r] > need[i][r]) {
            printf(RED "  [BANKER] Error: request exceeds declared maximum need.\n" RESET);
            return -1;
        }
    }
    /* Step 2: request ≤ available? */
    for (int r = 0; r < NUM_RESOURCES; r++) {
        if (request[r] > available[r]) {
            printf(YELLOW "  [BANKER] Vehicle %d must wait (insufficient resources).\n" RESET, vehicle_id);
            return 0;
        }
    }
    /* Step 3: pretend-allocate */
    for (int r = 0; r < NUM_RESOURCES; r++) {
        available[r]     -= request[r];
        allocation[i][r] += request[r];
        need[i][r]       -= request[r];
    }
    /* Step 4: safety check */
    if (safety_algorithm()) {
        printf(GREEN "  [BANKER] Request GRANTED for Vehicle %d.\n" RESET, vehicle_id);
        return 1;
    }
    /* Roll back */
    for (int r = 0; r < NUM_RESOURCES; r++) {
        available[r]     += request[r];
        allocation[i][r] -= request[r];
        need[i][r]       += request[r];
    }
    printf(RED "  [BANKER] Request DENIED (would cause unsafe state).\n" RESET);
    return 0;
}

/* ── Release Resources ────────────────────────────────────────── */
void banker_release(int vehicle_id, int release[NUM_RESOURCES]) {
    int i = vehicle_id - 1;
    for (int r = 0; r < NUM_RESOURCES; r++) {
        allocation[i][r] -= release[r];
        available[r]     += release[r];
        need[i][r]       += release[r];
    }
    printf(CYAN "  [BANKER] Vehicle %d released resources.\n" RESET, vehicle_id);
}

/* ── Print State Table ────────────────────────────────────────── */
void print_banker_state(void) {
    printf(BOLD "\n  %-6s  %-14s  %-20s  %-20s  %-20s\n" RESET,
           "ID", "Vehicle", "Max Need (L/I/P)", "Allocated (L/I/P)", "Need (L/I/P)");
    print_separator();

    for (int i = 0; i < n_vehicles; i++) {
        printf("  %-6d  %-14s  [%d %d %d]%-13s  [%d %d %d]%-13s  [%d %d %d]\n",
               shared->vehicles[i].id, shared->vehicles[i].name,
               max_need[i][0],   max_need[i][1],   max_need[i][2], "",
               allocation[i][0], allocation[i][1], allocation[i][2], "",
               need[i][0],       need[i][1],        need[i][2]);
    }

    print_separator();
    printf(CYAN "  Available Resources  →  Lanes: %d  Intersections: %d  Parking: %d\n" RESET,
           available[0], available[1], available[2]);
}

/* ── Full Banker Demo ─────────────────────────────────────────── */
void demo_banker(void) {
    print_section("Banker's Algorithm – Safe Resource Allocation");
    banker_init();
    print_banker_state();

    printf(BOLD "\n  Running safety check on initial state...\n" RESET);
    safety_algorithm();

    /* Grant a few requests */
    printf(BOLD "\n  Simulating resource requests...\n" RESET);
    int req1[NUM_RESOURCES] = {1, 0, 1};
    int req2[NUM_RESOURCES] = {0, 1, 0};
    int req3[NUM_RESOURCES] = {2, 1, 1};

    banker_request(1, req1);
    demo_pause(300);
    banker_request(2, req2);
    demo_pause(300);
    banker_request(3, req3);   /* may be denied if unsafe */
    demo_pause(300);

    printf(BOLD "\n  State after allocations:\n" RESET);
    print_banker_state();

    /* Release */
    banker_release(1, req1);
    banker_release(2, req2);
    printf(GREEN "\n  [BANKER] Resources released. Final safe state confirmed.\n" RESET);
    print_banker_state();
}
