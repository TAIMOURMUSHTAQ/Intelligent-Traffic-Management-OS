#ifndef TRAFFIC_H
#define TRAFFIC_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/shm.h>
#include <pthread.h>
#include <semaphore.h>
#include <time.h>
#include <errno.h>

/* ─── ANSI Colours ─────────────────────────────────────────────── */
#define RESET   "\033[0m"
#define RED     "\033[1;31m"
#define GREEN   "\033[1;32m"
#define YELLOW  "\033[1;33m"
#define BLUE    "\033[1;34m"
#define MAGENTA "\033[1;35m"
#define CYAN    "\033[1;36m"
#define WHITE   "\033[1;37m"
#define BOLD    "\033[1m"

/* ─── Constants ─────────────────────────────────────────────────── */
#define MAX_VEHICLES      20
#define MAX_RESOURCES      3   /* lanes, intersections, parking */
#define NUM_RESOURCES      3
#define MAX_INSTANCES     10   /* max units of each resource */
#define TIME_QUANTUM       2   /* RR quantum in seconds      */
#define SHM_KEY         1234
#define MSG_KEY         5678

/* ─── Vehicle Categories (for MQS) ─────────────────────────────── */
#define QUEUE_EMERGENCY    0
#define QUEUE_PUBLIC       1
#define QUEUE_REGULAR      2
#define NUM_QUEUES         3

/* ─── Vehicle States ────────────────────────────────────────────── */
#define STATE_WAITING      0
#define STATE_RUNNING      1
#define STATE_DONE         2
#define STATE_BLOCKED      3

/* ─── Vehicle / Process Structure ───────────────────────────────── */
typedef struct {
    int  id;
    char name[32];
    int  arrival_time;
    int  burst_time;
    int  remaining_time;
    int  priority;          /* 0 = highest (emergency) */
    int  queue_type;        /* QUEUE_EMERGENCY/PUBLIC/REGULAR */
    int  state;
    int  pid;
    int  wait_time;
    int  turnaround_time;
    int  finish_time;
    /* Banker's fields */
    int  max_need[NUM_RESOURCES];
    int  allocation[NUM_RESOURCES];
    int  need[NUM_RESOURCES];
} Vehicle;

/* ─── Shared Memory Layout ──────────────────────────────────────── */
typedef struct {
    int  available[NUM_RESOURCES];
    int  total[NUM_RESOURCES];
    int  emergency_signal;   /* 1 = emergency vehicle active */
    int  stop_all;           /* global stop flag             */
    int  vehicle_count;
    Vehicle vehicles[MAX_VEHICLES];
    pthread_mutex_t table_mutex;
} SharedData;

/* ─── Message Queue Structure ───────────────────────────────────── */
typedef struct {
    long mtype;
    char mtext[128];
} Message;

/* ─── Globals declared in main.c ────────────────────────────────── */
extern SharedData   *shared;
extern int           shmid;
extern int           msgid;
extern sem_t         lane_sem;
extern sem_t         intersection_sem;
extern pthread_mutex_t print_mutex;

/* ─── Function Prototypes ───────────────────────────────────────── */

/* vehicle.c */
void  generate_vehicles(int count);
void  print_vehicle_table(void);
Vehicle make_vehicle(int id, const char *name, int arrival,
                     int burst, int queue_type);

/* scheduler.c */
void  run_fcfs(void);
void  run_sjf(void);
void  run_rr(void);
void  run_mqs(void);
void  print_gantt(Vehicle *v, int n);
void  print_stats(Vehicle *v, int n);

/* sync.c */
void  init_sync(void);
void  destroy_sync(void);
void  enter_intersection(int vid);
void  leave_intersection(int vid);
void  enter_lane(int vid);
void  leave_lane(int vid);

/* banker.c */
int   banker_init(void);
int   banker_request(int vehicle_id, int request[NUM_RESOURCES]);
void  banker_release(int vehicle_id, int release[NUM_RESOURCES]);
int   safety_algorithm(void);
void  print_banker_state(void);

/* deadlock.c */
void  simulate_deadlock(void);
void  detect_and_recover(void);

/* ipc.c */
void  ipc_init(void);
void  ipc_send(int vtype, const char *msg);
void  ipc_receive_all(void);
void  ipc_cleanup(void);

/* signals.c */
void  setup_signal_handlers(void);
void  send_emergency(pid_t pid);

/* display.c */
void  print_header(void);
void  print_section(const char *title);
void  print_separator(void);
void  demo_pause(int ms);

#endif /* TRAFFIC_H */
