#include "traffic.h"

/* ── helpers ──────────────────────────────────────────────────── */
static void reset_vehicles(Vehicle *v, int n) {
    for (int i = 0; i < n; i++) {
        v[i].remaining_time  = v[i].burst_time;
        v[i].wait_time       = 0;
        v[i].turnaround_time = 0;
        v[i].finish_time     = 0;
        v[i].state           = STATE_WAITING;
    }
}

static int cmp_arrival(const void *a, const void *b) {
    return ((Vehicle*)a)->arrival_time - ((Vehicle*)b)->arrival_time;
}
static int cmp_priority(const void *a, const void *b) {
    if (((Vehicle*)a)->queue_type != ((Vehicle*)b)->queue_type)
        return ((Vehicle*)a)->queue_type - ((Vehicle*)b)->queue_type;
    return ((Vehicle*)a)->arrival_time - ((Vehicle*)b)->arrival_time;
}

/* ── Gantt chart ──────────────────────────────────────────────── */
typedef struct { int id; int start; int end; } GanttSlot;
#define MAX_SLOTS 200

static GanttSlot gantt[MAX_SLOTS];
static int gcount = 0;

static void gantt_add(int id, int start, int end) {
    if (gcount < MAX_SLOTS) {
        gantt[gcount].id    = id;
        gantt[gcount].start = start;
        gantt[gcount].end   = end;
        gcount++;
    }
}

void print_gantt(Vehicle *v, int n) {
    (void)v; (void)n;
    printf(BOLD "\n  Gantt Chart\n" RESET);

    /* top border */
    printf("  ");
    for (int i = 0; i < gcount; i++) {
        int w = gantt[i].end - gantt[i].start;
        for (int j = 0; j < w * 2 + 1; j++) printf("─");
        printf("┬");
    }
    printf("\n  │");

    /* vehicle labels */
    const char *colors[] = {RED, BLUE, GREEN, MAGENTA, CYAN,
                             YELLOW, WHITE, RED, BLUE, GREEN};
    for (int i = 0; i < gcount; i++) {
        int w = gantt[i].end - gantt[i].start;
        int label_w = w * 2;
        printf("%s V%-*d %s│", colors[gantt[i].id % 10],
               label_w - 2, gantt[i].id, RESET);
    }

    /* bottom border */
    printf("\n  ");
    for (int i = 0; i < gcount; i++) {
        int w = gantt[i].end - gantt[i].start;
        for (int j = 0; j < w * 2 + 1; j++) printf("─");
        printf("┴");
    }

    /* time axis */
    printf("\n  0");
    for (int i = 0; i < gcount; i++) {
        int w   = gantt[i].end - gantt[i].start;
        int pos = gantt[i].end;
        printf("%*d", w * 2 + 1, pos);
    }
    printf("\n");
}

/* ── Stats ────────────────────────────────────────────────────── */
void print_stats(Vehicle *v, int n) {
    printf(BOLD "\n  %-5s  %-14s  %-8s  %-12s  %-14s\n" RESET,
           "ID", "Vehicle", "Burst", "Wait Time", "Turnaround");
    print_separator();

    float avg_wait = 0, avg_tat = 0;
    for (int i = 0; i < n; i++) {
        printf("  %-5d  %-14s  %-8d  %-12d  %-14d\n",
               v[i].id, v[i].name, v[i].burst_time,
               v[i].wait_time, v[i].turnaround_time);
        avg_wait += v[i].wait_time;
        avg_tat  += v[i].turnaround_time;
    }
    print_separator();
    printf(GREEN "  Avg Wait: %.2f   Avg Turnaround: %.2f\n" RESET,
           avg_wait / n, avg_tat / n);
}

/* ══════════════════════════════════════════════════════════════ */
/*  1. FCFS                                                       */
/* ══════════════════════════════════════════════════════════════ */
void run_fcfs(void) {
    print_section("Scheduling Algorithm: FCFS (First Come First Serve)");
    printf("  Vehicles processed in arrival order.\n");

    int n = shared->vehicle_count;
    Vehicle v[MAX_VEHICLES];
    pthread_mutex_lock(&shared->table_mutex);
    memcpy(v, shared->vehicles, n * sizeof(Vehicle));
    pthread_mutex_unlock(&shared->table_mutex);

    qsort(v, n, sizeof(Vehicle), cmp_arrival);
    reset_vehicles(v, n);
    gcount = 0;

    int time = 0;
    for (int i = 0; i < n; i++) {
        if (time < v[i].arrival_time) time = v[i].arrival_time;
        v[i].state       = STATE_RUNNING;
        v[i].wait_time   = time - v[i].arrival_time;
        printf(GREEN "  [t=%2d] Vehicle %-14s entering intersection (burst=%d)\n" RESET,
               time, v[i].name, v[i].burst_time);
        gantt_add(v[i].id, time, time + v[i].burst_time);
        demo_pause(300);

        time += v[i].burst_time;
        v[i].finish_time     = time;
        v[i].turnaround_time = v[i].finish_time - v[i].arrival_time;
        v[i].state           = STATE_DONE;
        printf(CYAN  "  [t=%2d] Vehicle %-14s cleared.\n" RESET, time, v[i].name);
    }

    print_gantt(v, n);
    print_stats(v, n);
}

/* ══════════════════════════════════════════════════════════════ */
/*  2. SJF (non-preemptive)                                       */
/* ══════════════════════════════════════════════════════════════ */
void run_sjf(void) {
    print_section("Scheduling Algorithm: SJF (Shortest Job First)");
    printf("  Vehicles with shortest travel time served first.\n");

    int n = shared->vehicle_count;
    Vehicle v[MAX_VEHICLES];
    pthread_mutex_lock(&shared->table_mutex);
    memcpy(v, shared->vehicles, n * sizeof(Vehicle));
    pthread_mutex_unlock(&shared->table_mutex);

    reset_vehicles(v, n);
    gcount = 0;

    int done[MAX_VEHICLES] = {0};
    int time = 0, completed = 0;

    while (completed < n) {
        int idx = -1, min_burst = 9999;
        for (int i = 0; i < n; i++) {
            if (!done[i] && v[i].arrival_time <= time &&
                v[i].burst_time < min_burst) {
                min_burst = v[i].burst_time;
                idx = i;
            }
        }
        if (idx == -1) { time++; continue; }

        v[idx].state     = STATE_RUNNING;
        v[idx].wait_time = time - v[idx].arrival_time;
        printf(GREEN "  [t=%2d] Vehicle %-14s (burst=%d) getting green light.\n" RESET,
               time, v[idx].name, v[idx].burst_time);
        gantt_add(v[idx].id, time, time + v[idx].burst_time);
        demo_pause(300);

        time += v[idx].burst_time;
        v[idx].finish_time     = time;
        v[idx].turnaround_time = v[idx].finish_time - v[idx].arrival_time;
        v[idx].state           = STATE_DONE;
        done[idx] = 1;
        completed++;
        printf(CYAN "  [t=%2d] Vehicle %-14s cleared.\n" RESET, time, v[idx].name);
    }

    print_gantt(v, n);
    print_stats(v, n);
}

/* ══════════════════════════════════════════════════════════════ */
/*  3. Round Robin                                                */
/* ══════════════════════════════════════════════════════════════ */
void run_rr(void) {
    print_section("Scheduling Algorithm: Round Robin (Quantum = 2s)");
    printf("  Each lane gets a fair time slice of %d unit(s).\n", TIME_QUANTUM);

    int n = shared->vehicle_count;
    Vehicle v[MAX_VEHICLES];
    pthread_mutex_lock(&shared->table_mutex);
    memcpy(v, shared->vehicles, n * sizeof(Vehicle));
    pthread_mutex_unlock(&shared->table_mutex);

    qsort(v, n, sizeof(Vehicle), cmp_arrival);
    reset_vehicles(v, n);
    gcount = 0;

    int queue[MAX_VEHICLES * 10];
    int head = 0, tail = 0;
    int time = 0, completed = 0;
    int in_queue[MAX_VEHICLES] = {0};

    /* enqueue vehicles that have arrived at t=0 */
    for (int i = 0; i < n; i++) {
        if (v[i].arrival_time == 0) {
            queue[tail++] = i;
            in_queue[i]   = 1;
        }
    }

    while (completed < n) {
        /* Enqueue newly arrived vehicles */
        for (int i = 0; i < n; i++) {
            if (!in_queue[i] && v[i].arrival_time <= time &&
                v[i].remaining_time > 0) {
                queue[tail++] = i;
                in_queue[i]   = 1;
            }
        }

        if (head == tail) { time++; continue; }

        int idx = queue[head++];
        v[idx].state = STATE_RUNNING;
        int run = (v[idx].remaining_time < TIME_QUANTUM)
                  ? v[idx].remaining_time : TIME_QUANTUM;

        printf(GREEN "  [t=%2d] Vehicle %-14s runs for %d unit(s) (rem=%d)\n" RESET,
               time, v[idx].name, run, v[idx].remaining_time);
        gantt_add(v[idx].id, time, time + run);
        demo_pause(200);

        time                  += run;
        v[idx].remaining_time -= run;

        /* Enqueue again any newly arrived vehicles after the run */
        for (int i = 0; i < n; i++) {
            if (!in_queue[i] && v[i].arrival_time <= time &&
                v[i].remaining_time > 0) {
                queue[tail++] = i;
                in_queue[i]   = 1;
            }
        }

        if (v[idx].remaining_time == 0) {
            v[idx].state           = STATE_DONE;
            v[idx].finish_time     = time;
            v[idx].turnaround_time = time - v[idx].arrival_time;
            v[idx].wait_time       = v[idx].turnaround_time - v[idx].burst_time;
            completed++;
            printf(CYAN "  [t=%2d] Vehicle %-14s cleared.\n" RESET, time, v[idx].name);
        } else {
            v[idx].state  = STATE_WAITING;
            queue[tail++] = idx;
        }
    }

    print_gantt(v, n);
    print_stats(v, n);
}

/* ══════════════════════════════════════════════════════════════ */
/*  4. Multilevel Queue Scheduling                                */
/* ══════════════════════════════════════════════════════════════ */
void run_mqs(void) {
    print_section("Scheduling Algorithm: Multilevel Queue Scheduling (MQS)");
    printf("  " RED   "Q0 Emergency" RESET " > "
                BLUE  "Q1 Public Transport" RESET " > "
                GREEN "Q2 Regular Vehicles\n" RESET);

    int n = shared->vehicle_count;
    Vehicle v[MAX_VEHICLES];
    pthread_mutex_lock(&shared->table_mutex);
    memcpy(v, shared->vehicles, n * sizeof(Vehicle));
    pthread_mutex_unlock(&shared->table_mutex);

    qsort(v, n, sizeof(Vehicle), cmp_priority);
    reset_vehicles(v, n);
    gcount = 0;

    /* Separate into three queues */
    Vehicle *queues[NUM_QUEUES][MAX_VEHICLES];
    int      qsizes[NUM_QUEUES] = {0};

    for (int i = 0; i < n; i++)
        queues[v[i].queue_type][qsizes[v[i].queue_type]++] = &v[i];

    /* Sort each queue by arrival within the queue */
    /* (already sorted globally by priority then arrival) */

    const char *qcolors[NUM_QUEUES] = {RED, BLUE, GREEN};
    const char *qlabels[NUM_QUEUES] = {"Emergency", "Public Transport", "Regular"};

    int time = 0;
    for (int q = 0; q < NUM_QUEUES; q++) {
        if (qsizes[q] == 0) continue;
        printf(BOLD "\n  --- Queue %d: %s%s%s ---\n" RESET,
               q, qcolors[q], qlabels[q], RESET);
        for (int i = 0; i < qsizes[q]; i++) {
            Vehicle *vp = queues[q][i];
            if (time < vp->arrival_time) time = vp->arrival_time;
            vp->wait_time = time - vp->arrival_time;
            vp->state     = STATE_RUNNING;
            printf("%s  [t=%2d] %-14s cleared intersection (burst=%d)\n" RESET,
                   qcolors[q], time, vp->name, vp->burst_time);
            gantt_add(vp->id, time, time + vp->burst_time);
            demo_pause(250);
            time += vp->burst_time;
            vp->finish_time     = time;
            vp->turnaround_time = vp->finish_time - vp->arrival_time;
            vp->state           = STATE_DONE;
        }
    }

    print_gantt(v, n);
    print_stats(v, n);
}
