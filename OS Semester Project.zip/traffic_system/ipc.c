#include "traffic.h"

int msgid = -1;
int shmid  = -1;
SharedData *shared = NULL;

/* ── Shared Memory ───────────────────────────────────────────── */
void shm_init(void) {
    shmid = shmget(SHM_KEY, sizeof(SharedData), IPC_CREAT | 0666);
    if (shmid < 0) { perror("shmget"); exit(EXIT_FAILURE); }

    shared = (SharedData *)shmat(shmid, NULL, 0);
    if (shared == (SharedData *)-1) { perror("shmat"); exit(EXIT_FAILURE); }

    memset(shared, 0, sizeof(SharedData));

    /* Initialize the embedded mutex with PTHREAD_PROCESS_SHARED */
    pthread_mutexattr_t attr;
    pthread_mutexattr_init(&attr);
    pthread_mutexattr_setpshared(&attr, PTHREAD_PROCESS_SHARED);
    pthread_mutex_init(&shared->table_mutex, &attr);
    pthread_mutexattr_destroy(&attr);

    printf(GREEN "  [SHM] Shared memory attached (shmid=%d, size=%zu bytes)\n" RESET,
           shmid, sizeof(SharedData));
}

void shm_cleanup(void) {
    if (shared) {
        pthread_mutex_destroy(&shared->table_mutex);
        shmdt(shared);
        shared = NULL;
    }
    if (shmid >= 0) {
        shmctl(shmid, IPC_RMID, NULL);
        shmid = -1;
    }
}

/* ── Message Queue ───────────────────────────────────────────── */
void ipc_init(void) {
    shm_init();

    msgid = msgget(MSG_KEY, IPC_CREAT | 0666);
    if (msgid < 0) { perror("msgget"); exit(EXIT_FAILURE); }

    printf(GREEN "  [IPC]  Message queue created (msgid=%d)\n" RESET, msgid);
}

void ipc_send(int vtype, const char *msg) {
    if (msgid < 0) return;
    Message m;
    m.mtype = (long)(vtype + 1);   /* mtype must be > 0 */
    snprintf(m.mtext, sizeof(m.mtext), "%s", msg);
    if (msgsnd(msgid, &m, sizeof(m.mtext), 0) < 0)
        perror("msgsnd");
    else
        printf(BLUE "  [MSG→ type=%d] %s\n" RESET, vtype, msg);
}

void ipc_receive_all(void) {
    if (msgid < 0) return;
    Message m;
    printf(CYAN "\n  [IPC] Receiving all messages from queue:\n" RESET);

    for (int type = 1; type <= NUM_QUEUES; type++) {
        while (msgrcv(msgid, &m, sizeof(m.mtext), (long)type,
                      IPC_NOWAIT) > 0) {
            printf(GREEN "  [MSG← type=%ld] %s\n" RESET, m.mtype, m.mtext);
        }
    }
}

void ipc_cleanup(void) {
    if (msgid >= 0) {
        msgctl(msgid, IPC_RMID, NULL);
        msgid = -1;
        printf(CYAN "  [IPC] Message queue removed.\n" RESET);
    }
    shm_cleanup();
    printf(CYAN "  [IPC] Shared memory removed.\n" RESET);
}

/* ── Pipe IPC Demo ───────────────────────────────────────────── */
void demo_pipe_ipc(void) {
    print_section("IPC Demo 1: Pipe (Traffic Controller → Vehicle)");

    int pfd[2];
    if (pipe(pfd) < 0) { perror("pipe"); return; }

    pid_t child = fork();
    if (child < 0) { perror("fork"); return; }

    if (child == 0) {
        /* Child: vehicle receives signal */
        close(pfd[1]);
        char buf[128];
        ssize_t n = read(pfd[0], buf, sizeof(buf) - 1);
        if (n > 0) {
            buf[n] = '\0';
            printf(GREEN "  [VEHICLE PID=%d] Signal received via pipe: \"%s\"\n" RESET,
                   getpid(), buf);
        }
        close(pfd[0]);
        exit(0);
    } else {
        /* Parent: controller sends green light */
        close(pfd[0]);
        const char *signal_msg = "GREEN LIGHT - Intersection clear, proceed!";
        printf(YELLOW "  [CONTROLLER] Sending via pipe: \"%s\"\n" RESET, signal_msg);
        if (write(pfd[1], signal_msg, strlen(signal_msg)) < 0) perror("write pipe");
        close(pfd[1]);
        waitpid(child, NULL, 0);
    }
}

/* ── Message Queue Demo ──────────────────────────────────────── */
void demo_msgq_ipc(void) {
    print_section("IPC Demo 2: Message Queue (Priority Messages)");

    ipc_send(QUEUE_EMERGENCY, "EMERGENCY: Ambulance approaching - clear intersection NOW");
    demo_pause(100);
    ipc_send(QUEUE_PUBLIC,    "PUBLIC: Bus-101 requesting lane access");
    demo_pause(100);
    ipc_send(QUEUE_REGULAR,   "REGULAR: Car-201 waiting for traffic signal");
    demo_pause(100);
    ipc_send(QUEUE_REGULAR,   "REGULAR: Truck-301 requesting parking slot");
    demo_pause(100);

    ipc_receive_all();
}

/* ── Shared Memory Demo ──────────────────────────────────────── */
void demo_shm_ipc(void) {
    print_section("IPC Demo 3: Shared Memory (Traffic Controller ↔ Vehicles)");

    printf(YELLOW "  [CONTROLLER] Writing emergency flag to shared memory.\n" RESET);
    pthread_mutex_lock(&shared->table_mutex);
    shared->emergency_signal = 1;
    pthread_mutex_unlock(&shared->table_mutex);

    pid_t child = fork();
    if (child < 0) { perror("fork"); return; }

    if (child == 0) {
        /* Attach to same shared memory */
        SharedData *shm = (SharedData *)shmat(shmid, NULL, 0);
        if (shm == (SharedData *)-1) { perror("shmat child"); exit(1); }
        printf(GREEN "  [VEHICLE PID=%d] Read emergency flag from shared mem: %d\n" RESET,
               getpid(), shm->emergency_signal);
        if (shm->emergency_signal)
            printf(RED "  [VEHICLE PID=%d] Pulling over for emergency vehicle!\n" RESET,
                   getpid());
        shmdt(shm);
        exit(0);
    }
    waitpid(child, NULL, 0);

    /* Reset flag */
    pthread_mutex_lock(&shared->table_mutex);
    shared->emergency_signal = 0;
    pthread_mutex_unlock(&shared->table_mutex);
    printf(CYAN "  [CONTROLLER] Emergency flag cleared.\n" RESET);
}
