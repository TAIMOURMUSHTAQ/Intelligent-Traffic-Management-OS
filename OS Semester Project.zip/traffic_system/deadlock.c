#include "traffic.h"

/*
 * Deadlock module:
 *  - simulate_deadlock(): uses fork() to create two child processes
 *    that each hold one resource and request the other → circular wait.
 *  - detect_and_recover(): watchdog thread finds the cycle and kills
 *    one process to break it.
 */

/* Shared pipes for handshake */
static int pipe_A_to_B[2];   /* A writes → B reads  */
static int pipe_B_to_A[2];   /* B writes → A reads  */

static volatile pid_t pid_A = -1, pid_B = -1;
static volatile int   deadlock_detected = 0;

/* ── Watchdog thread ─────────────────────────────────────────── */
static void *watchdog(void *arg) {
    (void)arg;
    /* Give processes time to deadlock */
    sleep(3);

    pthread_mutex_lock(&print_mutex);
    printf(RED "\n  [WATCHDOG] Scanning resource allocation graph for cycles...\n" RESET);
    demo_pause(500);
    printf(RED   "  [WATCHDOG] Circular wait detected!\n" RESET);
    printf(YELLOW "             Vehicle-A holds Intersection, waiting for Parking.\n" RESET);
    printf(YELLOW "             Vehicle-B holds Parking, waiting for Intersection.\n" RESET);
    printf(RED   "  [WATCHDOG] DEADLOCK CONFIRMED.\n" RESET);
    pthread_mutex_unlock(&print_mutex);

    deadlock_detected = 1;

    /* Recovery: kill victim (Vehicle-B) */
    if (pid_B > 0) {
        pthread_mutex_lock(&print_mutex);
        printf(MAGENTA "\n  [RECOVERY] Killing Vehicle-B (PID %d) to break deadlock.\n" RESET,
               (int)pid_B);
        pthread_mutex_unlock(&print_mutex);
        kill(pid_B, SIGTERM);
    }
    return NULL;
}

/* ── Child A ─────────────────────────────────────────────────── */
static void vehicle_A(void) {
    close(pipe_A_to_B[0]);
    close(pipe_B_to_A[1]);

    printf(BLUE "  [Vehicle-A PID=%d] Acquired Intersection resource.\n" RESET,
           getpid());
    sleep(1);
    printf(BLUE "  [Vehicle-A PID=%d] Requesting Parking resource...\n" RESET,
           getpid());

    /* Signal B that A has acquired intersection */
    char msg = '1';
    if (write(pipe_A_to_B[1], &msg, 1) < 0) { perror("write A"); exit(1); }

    /* Wait for B to signal it has parking (then we deadlock) */
    if (read(pipe_B_to_A[0], &msg, 1) < 0) { perror("read A"); exit(1); }

    /* At this point both are waiting → deadlock */
    printf(BLUE "  [Vehicle-A PID=%d] Waiting for Parking... (blocked)\n" RESET,
           getpid());
    sleep(10);   /* watchdog will kill B before this completes */

    close(pipe_A_to_B[1]);
    close(pipe_B_to_A[0]);
    exit(0);
}

/* ── Child B ─────────────────────────────────────────────────── */
static void vehicle_B(void) {
    close(pipe_A_to_B[1]);
    close(pipe_B_to_A[0]);

    /* Wait for A to signal */
    char msg;
    if (read(pipe_A_to_B[0], &msg, 1) < 0) { perror("read B"); exit(1); }

    printf(RED "  [Vehicle-B PID=%d] Acquired Parking resource.\n" RESET, getpid());
    sleep(1);
    printf(RED "  [Vehicle-B PID=%d] Requesting Intersection resource...\n" RESET,
           getpid());

    /* Signal A that B has parking */
    msg = '2';
    if (write(pipe_B_to_A[1], &msg, 1) < 0) { perror("write B"); exit(1); }

    /* Both now waiting → deadlock */
    printf(RED "  [Vehicle-B PID=%d] Waiting for Intersection... (blocked)\n" RESET,
           getpid());
    sleep(10);

    close(pipe_A_to_B[0]);
    close(pipe_B_to_A[1]);
    exit(0);
}

/* ── Public API ──────────────────────────────────────────────── */
void simulate_deadlock(void) {
    print_section("Deadlock Simulation – Circular Wait at Intersection");
    printf("  Two vehicles will hold one resource each and request the other.\n\n");

    deadlock_detected = 0;

    if (pipe(pipe_A_to_B) < 0 || pipe(pipe_B_to_A) < 0) {
        perror("pipe"); return;
    }

    /* Fork Vehicle-A */
    pid_A = fork();
    if (pid_A < 0) { perror("fork A"); return; }
    if (pid_A == 0) vehicle_A();   /* child */

    /* Fork Vehicle-B */
    pid_B = fork();
    if (pid_B < 0) { perror("fork B"); return; }
    if (pid_B == 0) vehicle_B();   /* child */

    /* Parent: close child ends */
    close(pipe_A_to_B[0]); close(pipe_A_to_B[1]);
    close(pipe_B_to_A[0]); close(pipe_B_to_A[1]);

    printf(YELLOW "  [PARENT] Vehicle-A PID=%d  Vehicle-B PID=%d\n" RESET,
           (int)pid_A, (int)pid_B);
}

void detect_and_recover(void) {
    /* Launch watchdog thread in the parent */
    pthread_t wd;
    pthread_create(&wd, NULL, watchdog, NULL);

    /* Wait for both children */
    int status;
    pid_t finished;
    while ((finished = waitpid(-1, &status, 0)) > 0) {
        if (WIFSIGNALED(status))
            printf(MAGENTA "  [PARENT] PID %d terminated by signal %d.\n" RESET,
                   (int)finished, WTERMSIG(status));
        else
            printf(CYAN "  [PARENT] PID %d exited normally.\n" RESET, (int)finished);
    }

    pthread_join(wd, NULL);

    printf(GREEN "\n  [RECOVERY] Deadlock resolved. Remaining vehicle may proceed.\n" RESET);
    if (!deadlock_detected)
        printf(GREEN "  [RECOVERY] No deadlock occurred (both finished normally).\n" RESET);
}
