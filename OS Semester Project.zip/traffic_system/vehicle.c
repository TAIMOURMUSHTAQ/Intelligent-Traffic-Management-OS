#include "traffic.h"

static const char *QUEUE_NAMES[NUM_QUEUES] = {
    "Emergency", "Public   ", "Regular  "
};
static const char *STATE_NAMES[] = {
    "WAITING ", "RUNNING ", "DONE    ", "BLOCKED "
};
static const char *STATE_COLORS[] = {
    YELLOW, GREEN, CYAN, RED
};

Vehicle make_vehicle(int id, const char *name, int arrival,
                     int burst, int queue_type) {
    Vehicle v;
    memset(&v, 0, sizeof(v));
    v.id             = id;
    strncpy(v.name, name, sizeof(v.name) - 1);
    v.arrival_time   = arrival;
    v.burst_time     = burst;
    v.remaining_time = burst;
    v.queue_type     = queue_type;
    v.priority       = queue_type;   /* lower number = higher priority */
    v.state          = STATE_WAITING;
    v.pid            = -1;

    /* Banker's: random max_need within available resources */
    srand((unsigned)(id * 13 + arrival));
    for (int r = 0; r < NUM_RESOURCES; r++) {
        v.max_need[r]  = (rand() % 3) + 1;
        v.allocation[r] = 0;
        v.need[r]      = v.max_need[r];
    }
    return v;
}

void generate_vehicles(int count) {
    if (count > MAX_VEHICLES) count = MAX_VEHICLES;

    const char *names[] = {
        "Ambulance-1","Bus-101","Car-201","Truck-301","Car-202",
        "FireTruck-1","Bus-102","Car-203","Car-204","Ambulance-2",
        "Car-205","Bus-103","Car-206","Car-207","Car-208",
        "Ambulance-3","Bus-104","Car-209","Truck-302","Car-210"
    };
    int queue_types[] = {
        QUEUE_EMERGENCY, QUEUE_PUBLIC,   QUEUE_REGULAR, QUEUE_REGULAR, QUEUE_REGULAR,
        QUEUE_EMERGENCY, QUEUE_PUBLIC,   QUEUE_REGULAR, QUEUE_REGULAR, QUEUE_EMERGENCY,
        QUEUE_REGULAR,   QUEUE_PUBLIC,   QUEUE_REGULAR, QUEUE_REGULAR, QUEUE_REGULAR,
        QUEUE_EMERGENCY, QUEUE_PUBLIC,   QUEUE_REGULAR, QUEUE_REGULAR, QUEUE_REGULAR
    };

    pthread_mutex_lock(&shared->table_mutex);
    shared->vehicle_count = count;
    for (int i = 0; i < count; i++) {
        int burst   = (rand() % 5) + 1;
        int arrival = i;                    /* staggered arrivals */
        shared->vehicles[i] = make_vehicle(i + 1, names[i], arrival,
                                           burst, queue_types[i]);
    }
    pthread_mutex_unlock(&shared->table_mutex);
}

void print_vehicle_table(void) {
    pthread_mutex_lock(&print_mutex);
    printf("\n");
    printf(BOLD "  %-4s  %-14s  %-10s  %-7s  %-7s  %-9s  %-8s\n" RESET,
           "ID", "Vehicle", "Queue", "Arrival", "Burst", "State", "PID");
    print_separator();

    for (int i = 0; i < shared->vehicle_count; i++) {
        Vehicle *v = &shared->vehicles[i];
        const char *qcolor = (v->queue_type == QUEUE_EMERGENCY) ? RED :
                             (v->queue_type == QUEUE_PUBLIC)    ? BLUE : GREEN;
        printf("  %-4d  %-14s  %s%-10s%s  %-7d  %-7d  %s%-8s%s  %-8d\n",
               v->id, v->name,
               qcolor, QUEUE_NAMES[v->queue_type], RESET,
               v->arrival_time, v->burst_time,
               STATE_COLORS[v->state], STATE_NAMES[v->state], RESET,
               v->pid);
    }
    print_separator();
    pthread_mutex_unlock(&print_mutex);
}
